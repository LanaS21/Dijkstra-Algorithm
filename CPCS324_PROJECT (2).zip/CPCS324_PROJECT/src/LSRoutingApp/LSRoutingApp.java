/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LSRoutingApp;

import java.io.FileNotFoundException;

import graphFramework.*;

/**
 *
 * @author Lan
 */
public class LSRoutingApp {

	public static void main(String[] args) throws FileNotFoundException {

		Graph graph = new Graph(2000, 10000, false);
		graph.makeGraph();
		DijkstraAlg d = new DijkstraAlg(graph);
		long dijkstraStart = System.currentTimeMillis(); // start time
		d.dijkstra(0);
		long dijkstraEnd = System.currentTimeMillis();// end time
		System.out.println("-----------------------");
		System.out.println("Total runtime of dijkstra Algorithm :  " + (dijkstraEnd - dijkstraStart) + " MS");

		// Uncomment to test the
//		Graph graph2 = new Graph();
//		graph2.readGraphFromFile("input.txt");
//		DijkstraAlg d2 = new DijkstraAlg(graph2);
//		d2.dijkstra(0);
	}
}
