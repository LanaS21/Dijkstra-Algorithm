package LSRoutingApp;

import java.util.Objects;

import graphFramework.Vertex;


public class Router extends Vertex {
	String routerName;

	public Router() {
		super(0);
	}

	public Router(int label, Router router) {
		super(label);
		this.routerName = router.routerName;

	}

	public Router(int label, String RouterName) {
		super(label);
		this.routerName = RouterName;
	}

	public Router(String RouterName) {
		this.routerName = RouterName;
	}

	@Override
	public void displayInfo() {
		System.out.println("Rt. " + routerName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Router other = (Router) obj;
		return Objects.equals(routerName, other.routerName);
	}

	@Override
	public String toString() {
		return "Rt. " + routerName;
	}

	public String getRouterName() {
		return routerName;
	}
	
	

}
